import { JsonPipe } from '@angular/common';
import { Component, DestroyRef, inject, OnInit } from '@angular/core';
import { takeUntilDestroyed } from '@angular/core/rxjs-interop';
import { FormControl, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { finalize } from 'rxjs';
import { UsersService } from '../../services/users-service';
import { UserFormGroup } from './user-form.model';

@Component({
  selector: 'app-user-form',
  imports: [ReactiveFormsModule, JsonPipe],
  templateUrl: './user-form.html',
  styleUrl: './user-form.css',
})
export class UserForm implements OnInit {
  destroy = inject(DestroyRef);
  isSubmitting = false;
  private usersService = inject(UsersService);

  form = new FormGroup<UserFormGroup>({
    email: new FormControl('', [Validators.required, Validators.email]),
    name: new FormControl('', [Validators.required, Validators.minLength(3)]),
  });

  get email() {
    return this.form.controls.email;
  }
  get name() {
    return this.form.controls.name;
  }

  ngOnInit(): void {
    this.form.valueChanges.pipe(takeUntilDestroyed(this.destroy)).subscribe((value) => {
      console.log('[valueChanges]', value);
    });

    this.form.statusChanges.pipe(takeUntilDestroyed(this.destroy)).subscribe((status) => {
      console.log('[statusChanges]', status);
    });
  }

  onSubmit(): void {
    this.form.markAllAsTouched();

    if (this.form.invalid || this.isSubmitting) {
      console.warn('Formulario inválido', this.form.errors, this.form.value);
      return;
    }

    this.isSubmitting = true;

    const payload = this.form.getRawValue();

    this.usersService
      .createUser({
        email: payload.email ?? '',
        name: payload.name ?? '',
      })
      .pipe(
        takeUntilDestroyed(this.destroy),
        finalize(() => (this.isSubmitting = false)),
      )
      .subscribe({
        next: (user) => {
          console.log('Usuario creado correctamente', user);
          this.form.reset();
        },
        error: (err) => {
          console.error('Error al crear usuario', err);
        },
      });
  }
}
